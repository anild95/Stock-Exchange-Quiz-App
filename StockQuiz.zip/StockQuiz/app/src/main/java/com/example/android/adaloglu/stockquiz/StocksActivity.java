package com.example.android.adaloglu.stockquiz;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;


/**
 * Created by DALOGLU on 15.03.2018.
 */

public class StocksActivity extends AppCompatActivity {

    private int score = 0;
    private String name = "";
    private RadioGroup RadioGroup1;
    private int RadioButton1_correct;
    private RadioGroup RadioGroup2;
    private int RadioButton2_correct;
    private RadioGroup RadioGroup3;
    private int RadioButton_correct;
    private RadioGroup RadioGroup4;
    private int RadioButton4_correct;
    private RadioGroup RadioGroup5;
    private int RadioButton3_correct;
    private CheckBox CheckBox1_1;
    private CheckBox CheckBox1_2;
    private CheckBox CheckBox1_3;
    private CheckBox CheckBox1_4;
    private Button scoreButton;
    private Button resetButton;
    private EditText free_question;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stocks);

        RadioGroup1 = (RadioGroup) findViewById(R.id.q1_radio_group);
        RadioButton1_correct = R.id.answer_q1a1_rb;


        RadioGroup2 = findViewById(R.id.q2_radio_group);
        RadioButton2_correct = R.id.answer_q2a2_rb;

        RadioGroup3 = findViewById(R.id.q3_radio_group);
        RadioButton3_correct = R.id.answer_q3a3_rb;

        RadioGroup4 = findViewById(R.id.q4_radio_group);
        RadioButton4_correct = R.id.answer_q4a4_rb;

        RadioGroup5 = findViewById(R.id.q5_radio_group);
        RadioButton_correct = R.id.answer_q5a3_rb;

        CheckBox1_1 = findViewById(R.id.q6_check_1);
        CheckBox1_2 = findViewById(R.id.q6_check_2);
        CheckBox1_3 = findViewById(R.id.q6_check_3);
        CheckBox1_4 = findViewById(R.id.q6_check_4);

        scoreButton = findViewById(R.id.score_button);
        free_question = (EditText) findViewById(R.id.free_question);

    }

    /**
     * This method is called when the score button is clicked.
     */
    public void scoreButton (View view) {
        submitButton(scoreButton);

        score += isRadioGroup(RadioGroup1, RadioButton1_correct);
        score += isRadioGroup(RadioGroup2, RadioButton2_correct);
        score += isRadioGroup(RadioGroup3, RadioButton3_correct);
        score += isRadioGroup(RadioGroup4, RadioButton4_correct);
        score += isRadioGroup(RadioGroup5, RadioButton_correct);
        score += isCheckBox(CheckBox1_1, true);
        score -= isCheckBox(CheckBox1_2, false);
        score -= isCheckBox(CheckBox1_3, false);
        score += isCheckBox(CheckBox1_4, true);
        String scoreMessage = createScoreMessage();
        displayMessage(scoreMessage);
    }

    /**
     * Check status submit button
     */
    private void submitButton(Button button) {
        button.setEnabled(false);
    }

    /**
     * This method check status edit text.
     */

    private void free_question(EditText editText) {
        if (editText.getText().length() > 0) {
            name = editText.getText().toString();
        } else {
            Toast.makeText(this, R.string.elseEditText, Toast.LENGTH_SHORT).show();
        }
        //disable edit text
        editText.setEnabled(false);
    }

    /**
     * This method check status radio group.
     *
     * @return one points if the correct radio button is checked
     */
    private int isRadioGroup(RadioGroup radioGroup, int correctRadioButtonID) {
        int i = 0;
        int checkedisRadioGroup = radioGroup.getCheckedRadioButtonId();
        for (int s = 0; s < radioGroup.getChildCount(); s++) {
            // disable radio group
            (radioGroup.getChildAt(s)).setEnabled(false);
        }

        if (checkedisRadioGroup != 0 && checkedisRadioGroup == correctRadioButtonID) {
            i = 1;
        }
        return i;
    }

    /**
     * This method check status checkbox.
     *
     * @return one points if the checkbox is checked
     */
    private int isCheckBox(CheckBox checkBox, boolean selectedCorrect) {

        int i = 0;

        if (checkBox.isChecked() && selectedCorrect) {
             i = 1;
        }
        checkBox.setEnabled(false);
        return i;
    }


    /**
     * Takes the points of  RadioGroups and CheckBoxes.
     *
     * @return text summary
     */

    private String createScoreMessage() {
        String scoreMessage = name;
        scoreMessage += "\n You have " + score + "out of 7 Points.";
        return scoreMessage;
    }

    /**
     * This method is called when the reset button is clicked.
     */
    public void resetButton(View view) {
        resetScoreButton(scoreButton);
        resetFreeQuestion(free_question);
        resetRadioGroup(RadioGroup1);
        resetRadioGroup(RadioGroup2);
        resetRadioGroup(RadioGroup3);
        resetRadioGroup(RadioGroup4);
        resetRadioGroup(RadioGroup5);
        resetCheckBox(CheckBox1_1);
        resetCheckBox(CheckBox1_2);
        resetCheckBox(CheckBox1_3);
        resetCheckBox(CheckBox1_4);
        name = "";
        score = 0;
    }

    /**
     * This method reset score button.
     */

    private void resetScoreButton(Button button) {
        button.setEnabled(true);
    }

    /**
     * This method reset edit text.
     */

    private void resetFreeQuestion(EditText editText) {
        //clear edit text
        editText.setText("");
        //enable edit text
        editText.setEnabled(true);
    }

    /**
     * This method reset radio group.
     */
    private void resetRadioGroup(RadioGroup radioGroup) {
        //clear radio group
        radioGroup.clearCheck();
        //enable radio group
        for (int i = 0; i < radioGroup.getChildCount(); i++) {
            (radioGroup.getChildAt(i)).setEnabled(true);
        }
    }

    /**
     * This method reset checkbox.
     */
   private void resetCheckBox(CheckBox checkBox) {
       // uncheck checkbox
       checkBox.setChecked(false);
       //enable checkbox
       checkBox.setEnabled(true);
   }

    /**
     * This method displays the given text on screen.
     */
   private void displayMessage(String scoreMessage) {
       Toast.makeText(this, scoreMessage, Toast.LENGTH_LONG).show();
   }
}